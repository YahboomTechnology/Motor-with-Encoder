#include "ti_msp_dl_config.h"
#include "bsp_at8236.h"
#include "bsp_delay.h"
#include "bsp_usart.h"
#include "stdio.h"

int speed = 0,speed2 = 0;;
char buf[35] = {'\0'};
//������ Main function
int main(void)
{
    SYSCFG_DL_init();
	
	 //��������жϱ�־ Clear the serial port interrupt flag
    NVIC_ClearPendingIRQ(MYUART_INST_INT_IRQN);
    //ʹ�ܴ����ж� Enable serial port interrupt
    NVIC_EnableIRQ(MYUART_INST_INT_IRQN);
//	
		NVIC_EnableIRQ(GPIO_MULTIPLE_GPIOA_INT_IRQN);//ʹ���ⲿ�ж� Enable external interrupt
		init_motor();//�����ʱ���� Motor timer on
	
    while (1) 
    {    
			sprintf(buf,"speed1(10ms):%d\t speed2(10ms):%d\r\n",speed,speed2);
			uart0_send_string(buf);
			
			L1_control(600,0);//0-1000 
			L2_control(400,1);//0-1000 
			
			delay_ms(300);
			
       
    }
} 



