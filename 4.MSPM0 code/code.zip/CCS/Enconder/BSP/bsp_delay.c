#include "bsp_delay.h"
#include "ti_msp_dl_config.h"

volatile unsigned int delay_times = 0;

volatile unsigned int getspeed = 10;//��ȡ�ٶȱ�־ 10ms��ȡһ�� Get speed flag once every 10ms

extern volatile int32_t gEncoderCount_L1,gEncoderCount_L2;
extern int speed,speed2;

//����δ�ʱ��ʵ�ֵľ�ȷms��ʱ Accurate ms delay with tick timer
void delay_ms(unsigned int ms)//1ms��ʱ 1ms timing
{
    delay_times = ms;
    while( delay_times != 0 );
}


//�δ�ʱ���жϷ����� Tick timer interrupt service function
void SysTick_Handler(void)
{
    if( delay_times != 0 )
    {
        delay_times--;
    }
		
		 if( getspeed != 0 )
		{
				getspeed--;
		}
		else
		{
			getspeed = 10;
			speed = gEncoderCount_L1;
			speed2 = gEncoderCount_L2;
			gEncoderCount_L1 = 0;//��0 Clear
			gEncoderCount_L2 = 0;//��0 Clear
		}
		
		
}