#ifndef __BSP_TB6612_H_
#define __BSP_TB6612_H_

#include "ti_msp_dl_config.h"


void init_motor(void);

void L1_control(uint16_t motor_speed,uint8_t dir);
void L2_control(uint16_t motor_speed,uint8_t dir);
void R1_control(uint16_t motor_speed,uint8_t dir);
void R2_control(uint16_t motor_speed,uint8_t dir);

#endif

